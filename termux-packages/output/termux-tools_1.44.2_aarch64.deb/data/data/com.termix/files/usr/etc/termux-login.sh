##
## This script is sourced by /data/data/com.termix/files/usr/bin/login before executing shell.
##
